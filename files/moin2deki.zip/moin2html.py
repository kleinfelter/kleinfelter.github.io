#!/bin/env python
# -*- coding: Latin-1 -*-
"""
    @copyright: 2007 Kevin P. Kleinfelter
    @license: GNU LGPL, see LICENSE for details.

    I *ask* that you not redistribute these files.  Send people my site 
    http://www.kleinfelter.com/moin-to-deki-import/ 
    and ask them to download it from there.  (I'll get a few cents in
    the event someone clicks on one of the ads.)

This script is invoked by the builder.py script to convert the contents of
a MoinMoin page file into a format that can be uploaded to a Deki wiki.

You must edit myoptions.py to the values for your wiki before you run this!

"""
import sys
import os.path
from os.path import join
import re
import MoinMoin.parser.wiki
import MoinMoin.formatter.text_html
from os import system
from MoinMoin import wikiutil
from MoinMoin.action import AttachFile
from myoptions import dnsname


MoinMoin.formatter.text_html.line_anchors = False



##########################################################################
##########################################################################
class MyFormatter(MoinMoin.formatter.text_html.Formatter):

    ######################################################################
    # MoinMoin attachment links don't import well.  We'll replace them
    # with a reference to the Deki-generated links at the bottom of the page.
    ######################################################################
    def attachment_link(self, dummy1, dummy2, **kw):
        return '(see attached file below)'


    ######################################################################
    # MoinMoin attachment links don't import well.  We'll replace them
    # with a reference to the Deki-generated links at the bottom of the page.
    ######################################################################
    def attachment_image(self, dummy1, **kw):
        return '(see attached image below)'
    


##########################################################################
##########################################################################
class MyWikiParser(MoinMoin.parser.wiki.Parser):
        
    
    ######################################################################
    # I had to override setProcessor because there isn't a real
    # HTTP request object (just my mock object).
    ######################################################################
    def setProcessor(self, name):
        self.processor = None

    ######################################################################
    # When <tt class="backtickc"> was uploaded to Deki, Deki threw an
    # exception.  This override makes it just be <tt>.
    ######################################################################
    def _tt_bt_repl(self, word):
        """Remove 'backtick' from wiki.py's output. """
        return self.formatter.code(1) + self.formatter.text(word[1:-1]) + self.formatter.code(0)

        

##########################################################################
# Just a mock object, so I can use Moin formatter and parser.
# The methods do as little as possible -- just enough to prevent
# the Moin code from crashing when it is dealing with my mock Request object.
##########################################################################
class Clock:
    def __init__(self):
        self.timings = {}
        self.states = {}

    def start(self, timer):
        pass

    def stop(self, timer):
        pass

    def value(self, timer):
        return 1

    def dump(self):
        return ''
        

##########################################################################
# Just a mock object, so I can use Moin formatter and parser.
# The methods do as little as possible -- just enough to prevent
# the Moin code from crashing when it is dealing with my mock Request object.
##########################################################################
class Cfg:
    def __init__(self):
        self.siteid = dnsname
        self.macro_names = ''
        self.bang_meta = True
        self.data_underlay_dir = ''
        self.url_mappings = False
        self.attachments = False
        self.show_section_numbers = False
        self.shared_intermap = ''
        self.data_dir = '/tmp'
        self.interwikiname = 'mywiki'
        

##########################################################################
# Just a mock object, so I can use Moin formatter and parser.
# The methods do as little as possible -- just enough to prevent
# the Moin code from crashing when it is dealing with my mock Request object.
##########################################################################
class Request:
    def __init__(self, user):
        self.user = user
        self.text = ''
        self.form = ''
        self.cfg = Cfg()
        self._page_headings = 'pageheadings'
        self.clock = Clock()
        self.current_lang = 'en'
        self.content_lang = 'en'
        
    def __getattr__(self,name):
        if name == 'clock':
            return 'bar'
        else:
            raise AttributeError

    def getText(self, s):
        return s

    def getScriptname(self):
        return '.'

        
    def write(self,str):
        sys.stdout.write(str)
        
    def getPragma(self, name, default):
        return default
    

##########################################################################
# Just a mock object, so I can use Moin formatter and parser.
# The methods do as little as possible -- just enough to prevent
# the Moin code from crashing when it is dealing with my mock Request object.
##########################################################################
class Page:
    def __init__(self):
        self.hilite_re = False
        self.page_name = 'The Page Without a Name'
        
    def getPagePath(self, *args, **kw):
        return ''


##########################################################################
# Just a mock object, so I can use Moin formatter and parser.
# The methods do as little as possible -- just enough to prevent
# the Moin code from crashing when it is dealing with my mock Request object.
##########################################################################
class User:
    def __init__(self):
        self.show_nonexist_qm = False
        self.wikiname_add_spaces = True
        self.show_topbottom = False
                


##########################################################################
# Just a mock object, so I can use Moin formatter and parser.
# The methods do as little as possible -- just enough to prevent
# the Moin code from crashing when it is dealing with my mock Request object.
##########################################################################
class RawText:
    def __init__(self,req):
        self.req = req
    def expandtabs(self):
        return self.req.text



##########################################################################
# Just a mock object, so I can use Moin formatter and parser.
# The methods do as little as possible -- just enough to prevent
# the Moin code from crashing when it is dealing with my mock Request object.
##########################################################################
class Title:
    def __init__(self):
        pass
    def setdefault(self, x, y):
        pass
    def __getitem__(self, i):
        return 0
        
    def __setitem__(self, i, j):
        return 0



##########################################################################
# Main program begins here.
##########################################################################
error = False

if len(sys.argv) == 3:
    if os.path.isdir(sys.argv[1]) and os.path.isfile(sys.argv[2]):
        pass
    else:
        print("File not found")
        error = True
else:
    error = True
if error:
    print("pass a command-line argument that is the full path name of a MoinMoin data directory\n(contains 'pages' and 'plugin' subdirectories) and the full path name of a file containing a MoinMoin page,\nand this script will print to stdout, the content of the page, converted to HTML\n")
    exit(1)

user = User()
req = Request(user)

parser = MyWikiParser(False, req)
parser.raw = RawText(req)
parser.titles = Title()
formatter = MyFormatter(req)
formatter.page = Page()
req.page = formatter.page
req.rootpage = req.page

FILE = open(sys.argv[2],"r")
s = FILE.read()
FILE.close()

req.cfg.data_dir = sys.argv[1]

s = s.replace("\x0a\x0d", "\x0a")


# I'm certain there is a better way to do this.  The problem is that parser.format wants to convert from ASCII-128 to Unicode, and it fails on ASCII-256
s = s.replace("�", "'")    # Replace fancy curved apostrophe with ordinary apostrophe
s = re.sub(r'[\x80-\xFF]', '?', s)
req.text = s.replace("???s", "'s")      # Seriously ugly hack for unicode fancy-apostrophe followed by s


parser.format(formatter)
exit(0)

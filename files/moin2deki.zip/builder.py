"""
    @copyright: 2007 Kevin P. Kleinfelter
    @license: GNU LGPL, see LICENSE for details.

    I *ask* that you not redistribute these files.  Send people my site 
    http://www.kleinfelter.com/moin-to-deki-import/ 
    and ask them to download it from there.  (I'll get a few cents in
    the event someone clicks on one of the ads.)


This program takes a MoinMoin data directory name (use the full path name
of the MoinMoin directory named 'data').  It generates a shell script for
uploading pages to a Deki wiki.  It also generates a file with the content
for each page to be uploaded.

This program runs pretty slow because it makes a lot of calls to os.system,
to invoke a stand-alone program to convert a MoinMoin page file into a
file that can be uploaded to a Deki wiki.

You must edit myoptions.py to the values for your wiki before you run this!

"""
import sys
import re
from os import listdir, system
from os.path import join
import os

from myoptions import username, password, dnsname



##########################################################################
# Convert a Moin file name into a page name usable by Deki.
##########################################################################
def Titleize(s):
    s2 = s
    s2 = s2.replace(' ', '%2520')         # 20 is ' '
    s2 = s2.replace('(20)', '%2520')      # 20 is ' '
    s2 = s2.replace('+', '%252b')         # 2b is '+'
    s2 = s2.replace('(2b)', '%252b')      # 2b is '+'
    s2 = s2.replace('(2f)', '%252f')      # 2F is '/' so it is a subpage
    return s2



##########################################################################
# Working on a moin content directory that contains
# the files and subdirectories that make up a moin page + revision
# history + attachments
##########################################################################
def ProcessDir(mypath, dir):
    if (dir == 'BadContent'):
        return
    if re.match(r'.*MoinEditorBackup$', dir):
        return

    current = join(mypath, 'pages', dir,'current')
    try:
        FILE = open(current)
        number = FILE.read(8)
        FILE.close()
        pageFile = join(mypath, 'pages', dir, 'revisions', number)
        print pageFile + "\n"
        
        filename = dir + '.html'
        filename = filename.replace('(', '_')
        filename = filename.replace(')', '_')
        cmdline = 'python moin2html.py ' + mypath + ' ' + pageFile + '> ' + join('.', 'loadfiles', filename)
        system(cmdline)
        
        pagetitle = Titleize(dir)
        
        cmdline = ""
        cmdline = cmdline + 'echo\n'
        cmdline = cmdline + "echo '" + dir + "'\n"
        cmdline = cmdline + 'curl -b cookies.txt --data-binary @'
        cmdline = cmdline + 'loadfiles/' + filename         # The curl must be run from Linux or cygwin, so we always need a '/' and not a '\\'
        cmdline = cmdline + ' -H "Content-type: text/html" "http://'
        cmdline = cmdline + dnsname + '/@api/deki/pages/='
        cmdline = cmdline + pagetitle
        cmdline = cmdline + '/contents?Abort=never&Edittime=20070101111111" > /tmp/curl-temp 2> /dev/null\n'
        cmdline = cmdline + 'grep \'edit status="success\' /tmp/curl-temp > /dev/null || grep \'page.overwritten\' /tmp/curl-temp > /dev/null\n'
        cmdline = cmdline + "if [ $? -ne 0 ] ; then echo 'Upload of " + dir + " failed.  Check /tmp/curl-temp for the reason.  Press a key to continue.'; read; fi\n"

        SF.write(cmdline)
    except IOError:
        pass



##########################################################################
# Main program begins here.
##########################################################################
error = False        
if len(sys.argv) == 2:
    if os.path.isdir(sys.argv[1]):
        pass
    else:
        print("Directory not found")
        error = True
else:
    error = True
if error:
    print("pass a single command-line argument that is the full path name of a MoinMoin data directory\n(the one that contains the 'pages' subdirectory),\nand this script will create in the current directory:\n")
    print("   * A 'loadfiles' subdirectory containing a lot of files, containing content for your Dekiwiki\n  * A load2deki.sh shell script to load the files to your Dekiwiki\n")
    print("   Note: Tested on cygwin and Linux (Centos 4)\n")
    exit(1)


DATADIR = sys.argv[1]
PAGESDIR = join(DATADIR, 'pages')
SCRIPTNAME = join('.', 'load2deki.sh')

SF = open(SCRIPTNAME, 'wb')
SF.write('#!/bin/bash\n')
SF.write('curl -c cookies.txt http://' + username + ':' + password + '@' + dnsname + '/@api/deki/users/authenticate\n')

try:
    os.mkdir(join('.', 'loadfiles'))
except:
    pass

for dir in listdir(PAGESDIR):
    ProcessDir(DATADIR, dir)
    
SF.close()

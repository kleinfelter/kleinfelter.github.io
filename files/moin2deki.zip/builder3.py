"""
    @copyright: 2007 Kevin P. Kleinfelter
    @license: GNU LGPL, see LICENSE for details.

    I *ask* that you not redistribute these files.  Send people my site 
    http://www.kleinfelter.com/moin-to-deki-import/ 
    and ask them to download it from there.  (I'll get a few cents in
    the event someone clicks on one of the ads.)

This program takes a MoinMoin data directory name (use the full path name
of the MoinMoin directory named 'data').  It generates a shell script for
adding users to a Deki wiki.  It also generates a shell script to email
a notice to each user of his new user name and password.

This script and the generated scripts run pretty quicky.  The mail script has
delays embedded, in order to reduce your chances of getting labeled as spam,
but you can delete these delays if you wish.

You must edit myoptions.py to the values for your wiki before you run this!


"""
import sys
import re
from os import listdir, system
from os.path import join
import os

from myoptions import username, password, dnsname





##########################################################################
# Scan through a Moin user file and pick out the email address
# and the user name.  We return a slightly altered edition of the
# user-file's name as a new password for the user.  (Since we can't reverse
# the SHA-encrypted password, we have to give each user a new password.)
##########################################################################
def GetEmailAndName(filepath, filename):
    file = open(filepath, 'r')
    s = file.readlines()
    file.close()
    email = 'unknown@example.com'
    name = 'UnknownUser'

    for line in s:
        if re.match(r'email\=', line):
            email = line[6:-1]
        if re.match(r'name\=', line):
            name = line[5:-1]

    password = filename.replace('.', '')
    return email, name, password



##########################################################################
# Cheezy convert from DOS path to Cygwin path.
##########################################################################
def rightslash(s):
    s = s.replace('\\','/')
    if s[1:2] == ':':
        s = '/cygdrive/' + s[0:1] + s[2:]
    return s



##########################################################################
# Working on a moin content directory that contains
# the files and subdirectories that make up a moin page + revision
# history + attachments
##########################################################################
def ProcessDir(dospath, cygpath, afile):
    if re.match(r'.*\d\d$', afile):
        pass
    else:
        return

    if os.path.isdir(join(dospath, afile)):
        return

    email, originalname, password = GetEmailAndName(join(dospath, afile), afile)
    name = originalname.lower()
    name = re.sub(r' ', '', name)

    user_xml_file = 'userfiles/' + name + '.xml'

    cmd = ''
    cmd = cmd + 'curl -b cookies.txt -d @' + user_xml_file + ' -H "Content-type: text/xml" ' + '"http://' + dnsname + '/@api/deki/users?accountpassword=' + password + '"\n'

    SF.write(cmd)
    
    outfile = open('./' + user_xml_file, 'wb')
    outfile.write('<user><username>' + name + '</username><fullname>' + originalname + '</fullname><email>' + email + '</email><permissions.user><role>Contributor</role></permissions.user></user>')
    outfile.close()
    
    outfile = open ('./' + user_xml_file + '.mail', 'wb')
    outfile.write('The wiki at ' + dnsname + ' has been upgraded to use new software.\nAll of the pages from the old wiki have been imported into the new wiki.\nYour user ID on the new wiki is ' + name + ' and your password has been set to ' + password + '\n')
    outfile.write('Sincerely,\nThe wiki manager at ' + dnsname + '\nwiki.manager@' + dnsname + '\n')
    outfile.close()

    MF.write('mail -s "Wiki_Software_Upgraded" ' + email + ' < ./' + user_xml_file + '.mail\n')
    MF.write('sleep 30   # If you don\'t want this delay between emails, mass-replace "sleep 30" with "sleep 1", but be aware that your email may get treated as spam by some servers\n')
    print "(" + email + "," + name + ")\n"



##########################################################################
# Main program begins here.
##########################################################################
error = False        
if len(sys.argv) == 2:
    if os.path.isdir(sys.argv[1]):
        pass
    else:
        print("Directory not found")
        error = True
else:
    error = True
if error:
    print("pass a single command-line argument that is the full path name of a MoinMoin data directory\n(the one that contains the 'user' subdirectory),\nand this script will create in the current directory:\n")
    print("   * A load2deki3.sh shell script to load the users to your Dekiwiki\n")
    print("   Note: Tested on cygwin and Linux (Centos 4)\n")
    exit(1)

DATADIR = sys.argv[1]
USERDIR = join(DATADIR, 'user')
CYGUSERDIR = rightslash(USERDIR)
SCRIPTNAME = join('.', 'load2deki3.sh')

MF = open('./mail-new-pw.sh', 'wb')
SF = open(SCRIPTNAME, 'wb')
SF.write('#!/bin/bash\n')
MF.write('#!/bin/bash\n')
SF.write('curl -c cookies.txt http://' + username + ':' + password + '@' + dnsname + '/@api/deki/users/authenticate\n')
MF.write('# This script will send an email to all wiki users, telling them of their new ID and password.\n#You must run it on a computer that understands the Unix/Linux "mail" command.\n')
try:
    os.mkdir(join('.', 'userfiles'))
except:
    pass

for user in listdir(USERDIR):
    ProcessDir(USERDIR, CYGUSERDIR, user)
    
SF.close()
MF.close()
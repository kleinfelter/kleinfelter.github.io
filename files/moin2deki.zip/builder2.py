"""
    @copyright: 2007 Kevin P. Kleinfelter
    @license: GNU LGPL, see LICENSE for details.

    I *ask* that you not redistribute these files.  Send people my site 
    http://www.kleinfelter.com/moin-to-deki-import/ 
    and ask them to download it from there.  (I'll get a few cents in
    the event someone clicks on one of the ads.)

This program takes a MoinMoin data directory name (use the full path name
of the MoinMoin directory named 'data').  It generates a shell script for
uploading attachments to a Deki wiki.

This program runs pretty fast, but the script it generates can take a LONG
time to complete if you have a lot of large attachments to upload.


You must edit myoptions.py to the values for your wiki before you run this!

"""
import sys
import re
from os import listdir, system
from os.path import join
import os

from myoptions import username, password, dnsname



##########################################################################
# Convert a Moin file name into a page name usable by Deki.
##########################################################################
def Titleize(s):
    s2 = s
    s2 = s2.replace(' ', '%2520')         # 20 is ' '
    s2 = s2.replace('(20)', '%2520')      # 20 is ' '
    s2 = s2.replace('+', '%252b')         # 2b is '+'
    s2 = s2.replace('(2b)', '%252b')      # 2b is '+'
    s2 = s2.replace('(2f)', '/')          # 2F is '/'
    s2 = s2.replace('(', '_')
    s2 = s2.replace(')', '_')
    return s2


##########################################################################
# Use the file extension (e.g. ".jpg") to set the MIME content-type in
# the HTTP header.
##########################################################################
def getContentType(fname):
    ctype = "Content-type: "
    if re.match(r'.*\.jpg$', fname) or re.match(r'.*\.jepg$', fname):
        return ctype + 'image/jpeg'
    if re.match(r'.*\.png$', fname):
        return ctype + 'image/x-png'
    if re.match(r'.*\.gif$', fname):
        return ctype + 'image/gif'
    if re.match(r'.*\.tif$', fname) or re.match(r'.*\.tiff$', fname):
        return ctype + 'image/tiff'
    return ctype + 'application/octet-stream'

    


##########################################################################
# For one file, generate the shell script lines that will upload 
# the file as an attachment.
##########################################################################
def AttachFile(attachDir, fileName, pageDirName):
    newPageName = Titleize(pageDirName)
    newFileName = Titleize(fileName)
    newFileName = newFileName.replace('.', '%252e')
    print attachDir + "\n"

    cmdline = ''
    cmdline = cmdline + "echo\n"
    cmdline = cmdline + "echo '" + pageDirName + '/' + fileName + "'\n"
    cmdline = cmdline + 'curl -b cookies.txt -X PUT --data-binary "@'
    cmdline = cmdline + attachDir + '/' + fileName + '"'
    cmdline = cmdline + ' -H "' + getContentType(attachDir + '/' + fileName)
    cmdline = cmdline + '" "http://' + dnsname + '/@api/deki/pages/='
    cmdline = cmdline + newPageName
    cmdline = cmdline + '/files/=' + newFileName + '" > /tmp/curl2-log\n'
    cmdline = cmdline + "if [ $? -ne 0 ] ; then echo 'Upload of " + fileName + " failed.  Check /tmp/curl-temp for the reason.  Press a key to continue.'; read; fi\n"

    SF.write(cmdline)




##########################################################################
# Cheezy convert from DOS path to Cygwin path.
##########################################################################
def rightslash(s):
    s = s.replace('\\','/')
    if s[1:2] == ':':
        s = '/cygdrive/' + s[0:1] + s[2:]
    return s



##########################################################################
# Working on a moin content directory that contains
# the files and subdirectories that make up a moin page + revision
# history + attachments
##########################################################################
def ProcessDir(dospath, cygpath, dir):
    attachments = join(dospath, 'pages', dir,'attachments')
    cygattachments = cygpath + '/pages/' + dir + '/attachments'

    if (dir == 'BadContent'):
        return
    if (re.match(r'.*MoinEditorBackup$', dir)):
        return

    if os.path.isdir(attachments):
        pass
    else:
        return

    for afile in listdir(attachments):
        AttachFile(cygattachments, afile, dir)



##########################################################################
# Main program begins here.
##########################################################################
error = False        
if len(sys.argv) == 2:
    if os.path.isdir(sys.argv[1]):
        pass
    else:
        print("Directory not found")
        error = True
else:
    error = True
if error:
    print("pass a single command-line argument that is the full path name of a MoinMoin data directory\n(the one that contains the 'attachments' subdirectory),\nand this script will create in the current directory:\n")
    print("   * A load2deki2.sh shell script to load the attachments to your Dekiwiki\n")
    print("   Note: Tested on cygwin and Linux (Centos 4)\n")
    exit(1)


DATADIR = sys.argv[1]
CYGDATADIR = rightslash(DATADIR)
PAGESDIR = join(DATADIR, 'pages')
SCRIPTNAME = join('.', 'load2deki2.sh')

SF = open(SCRIPTNAME, 'wb')
SF.write('#!/bin/bash\n')
SF.write('curl -c cookies.txt http://' + username + ':' + password + '@' + dnsname + '/@api/deki/users/authenticate\n')

for dir in listdir(PAGESDIR):
    ProcessDir(DATADIR, CYGDATADIR, dir)
    
SF.close()

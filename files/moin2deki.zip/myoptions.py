"""
    @copyright: 2007 Kevin P. Kleinfelter
    @license: GNU LGPL, see LICENSE for details.

    I *ask* that you not redistribute these files.  Send people my site 
    http://www.kleinfelter.com/moin-to-deki-import/ 
    and ask them to download it from there.  (I'll get a few cents in
    the event someone clicks on one of the ads.)

Edit this file to the values for your wiki before you run the conversion 
scripts.

"""
username = 'username1'
password = 'notmypassword'
dnsname = 'www.example.com'

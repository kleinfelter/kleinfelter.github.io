#!/bin/bash
echo 'This script will create a suspenders-based project, tailored to my preferences'
echo -n 'Enter the path of the directory that will be the parent directory for your project. (Note that you must not use "~".):'
read apath
echo -n 'Enter the name of your project (use only a-z and 0-9):'
read projectname

cd "$apath"
rm -rf suspenders
git clone git://github.com/thoughtbot/suspenders.git
cd suspenders
./script/create_project "$projectname"

# Now we'll get rid of the missing gemspec error.
cd "../$projectname/vendor/gems"
rm -rf thoughtbot-clearance-0.8.2
git clone git://github.com/thoughtbot/clearance.git thoughtbot-clearance-0.8.2 cd ../..
rake gems:refresh_specs

echo -n 'I will start vi.  Comment-out the Redcloth entry.  Press Enter to continue.'
read dummy
vi config/environment.rb

echo -n 'I will start vi.  Comment-out the shoulda entry.  Press Enter to continue.'
read dummy
vi config/environments/test.rb

# Install rspec and rspec-rails:
ruby script/plugin install git://github.com/dchelimsky/rspec.git -r 'refs/tags/1.2.7'
ruby script/plugin install git://github.com/dchelimsky/rspec-rails.git -r 'refs/tags/1.2.7.1'
ruby script/generate rspec

# Get rid of git
find . -name .git -exec rm -rf \{\} \; 2>/dev/null

echo -n 'Enter the Subversion server URL to check-in the project as (enter the empty string to skip):'
read svnurl

if [ -n "$svnurl" ] ; then
    echo -n 'Enter the subversion user-ID:'
    read uname
    echo -n 'Enter the subversion password for $uname:'
    read pword
    svn import . "$svnurl" -m "Initial project commit." --username $uname --password $pword fi

# clean-up
rm -rf ../suspenders
